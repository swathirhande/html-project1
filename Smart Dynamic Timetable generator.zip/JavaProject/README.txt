A Pen created at CodePen.io. You can find this one at https://codepen.io/Swathi_R/pen/rbLpPE.

 A modern responsive login form